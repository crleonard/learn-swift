// Lesson 3 - Operators

import UIKit

// Arithmetic Operators

// Previously we have used the assignment operator '='

var myExample = 25

// In addition to assignment, Swift also supports the
//4 basic math opperators. These are;
// Addition '+'
// Subtraction '-'
// Multiplication '*'
// Division '/'

var example1 = 10 + 5       // Equals 15
var example2 = 15 - 10       // Equals 5
var example3 = 10 * 5       // Equals 50
var example4 = 20 / 4  // Equals 5

//------------------------------------------------------------------------------

// Compound Assignment Operators

// Swift provides compound assignment operators that are used to combine the assignment
// '=' with another operation. This can be used to help eliminate the ammount of required code.

var exampleNumber = 50

exampleNumber += 10 // exampleNumber = exampleNumber + 10
exampleNumber -= 10 // exampleNumber = exampleNumber - 10
exampleNumber *= 10 // exampleNumber = exampleNumber * 10
exampleNumber /= 10 // exampleNumber = exampleNumber / 10

//------------------------------------------------------------------------------

// You can also use the addition operator for connecting multiple Strings.
// You can view the output in the compiler view.

print("Hello, " + "world!")  // This will print one string of "Hello World".

//------------------------------------------------------------------------------

// Comparison Operators

// Equal to                  (a == b)
// Not equal to              (a != b)
// Greater than              (a > b)
// Less than                 (a < b)
// Greater than or equal to  (a >= b)
// Less than or equal to     (a <= b)

1 == 1   // True, 1 is equal to 1
2 != 1   // True, 2 is not equal to 1
2 > 1    // True, 2 is greater than 1
1 < 2    // True, 1 is less than 2
1 >= 1   // True, 1 is greater than or equal to 1
2 <= 1   // False, 2 is not less than or equal to 1

//------------------------------------------------------------------------------

// Logical Operators

// Logical operators modify or combine the Boolean logic values true and false. 
// Swift supports the three standard logical operators found in C-based languages:
//
// Logical AND (a && b) - Returns true if both expressions are true
// Logical OR  (a || b) - Returns true if either of the two expressions are true
// Logical NOT (!a)     - Negates or inverts the expression's result.

2 > 1 && 4 > 2   // true, because both 2 > 1 AND 4 > 2 are true.

2 > 1 || 0 > 100 // true, because at least one of the expressions is true.

!(1 == 1)        // false because 1 is equal to 1 but the ! inverts the result
                 // and makes it false.

//------------------------------------------------------------------------------

// The Remainder Operator

// The remainder operator (a % b) works out how many multiples of b will fit
// inside a and returns the value that is left over (known as the remainder).

// For example, if we divide 9 by 4 we get 2 since at least two 4's can fit into 9
// but what about the remainder?
var quotient = 9 / 4

print("How many 4's can fit into 9: \(quotient)")

// If we want to know just about the remainder we can use the '%' or the remainder
// operator to find out what the remainder is after the 9 is divided by 4.
var remainder = 9 % 4

print("The remainder of dividing 9 by 4 is: \(remainder)")

// While the remainder operator is not used very often in day-to-day coding, it
// often pops in interview questions where you will be asked to identify numbers
// that are the "multiples of some other number", or "divisible by some other number".

// For example, if you're asked to identity all the numbers that are "multiples of three"
// then you could use the remainder operator to find the like so:

15 % 3 == 0 // Is 15 a multiple of 3?

10 % 3 == 0 // Is 10 a multiple of 3?
