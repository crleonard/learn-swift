// Lesson 1 - Varibles

import UIKit

// This one simple comment.

//------------------------------------------------------------------------------

/*
This is a type of comment
 used over multiple lines.
*/

//------------------------------------------------------------------------------

// Use "var" to declare a variable.

var myAge = 22

//------------------------------------------------------------------------------

/*
 You can use the 'let' keyword to declare a constant.
 A constant is ued to hold a value, though this can't
 Be changed once its assigned.
 */

let maxHealthLevel = 100

//------------------------------------------------------------------------------

// You can also declare multiple variables together.
// To do this, simply seperate with a commar.

var age = 22, health = 100

//------------------------------------------------------------------------------

// Variable and constant names can contain almost any character, including
// Unicode characters such as the symbol for Pi or emojis.
let π = 3.14159
let my🐶name = "Spot"

// To insert an emoji use: Command + Ctrl + Spacebar
// In most cases, you should really avoid this!

// One of the possible valid uses of this would be for programmers to write
// their code in their own native language.
let 你好 = "你好世界"

//------------------------------------------------------------------------------

// Swift gives us several built-in functions which we are designed to help us out.
// For example, we can use the print() function to print our data to the console.

var shopKeeperText = "Would you like to buy something for your adventure?"

print(shopKeeperText)

shopKeeperText = "How about a sword or a new suit of armor?"

print(shopKeeperText)

//------------------------------------------------------------------------------

// If we want to build-up a String using some of our variables, we can use
// string interpolation to include the name of a constant or variable
// into another string.

// Wrap the 'var' in parentheses and escape it with a backslash.
// Example:   \(varName)
// Below is an example of how you can do this together.

var item = "iPhone"
var price = 1000
var weeks = 6

print("Are you sure you want to purchase this \(item) for \(price) pounds?")

item = "Swift Lesson"
weeks = 6

print("Are you sure you want to enrole in this '\(item)' for \(weeks) weeks?")

item = "Ultimate Swift Help"
price = 500

print("Are you sure you want to purchase the \"\(item)\" for \(price) pounds?")
