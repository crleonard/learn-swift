// Lesson 4 - Collection Types

import UIKit

// Swift provides three collection types.
// These are arrays, dictionaries & sets.
// They are all used for storing values.

// Definitions of each are below.

// An Array is an ordered collections of values.
// Dictionaries are unordered collections of value pairs & associations.
// Lastly, Sets are unordered collections of unique values.

//------------------------------------------------------------------------------

// Creating an empty Array is simple.

var exampleArray = [String]()

// For the purpose of this example, this empty Array will be the base for out shape names.
// When we add values to the Array, Swift will store it.

var shapeList = ["Square", "Circle", "Triangle"]

// The order in arrays are always maintained.
// This means we can index with a number in the list.

print(shapeList[0])
print(shapeList[1])
print(shapeList[2])

// We can also print the entire content of an Array, simply usung the "print" command.

print(shapeList)

// Always be caucious when indexing an Array Item.
// If you index an item that doesn't exist, for example 'print(shapeList[3])', this can cause a crash.

// We can also use the subscript syntax to assign a new value to the var being stored within.

shapeList[2] = "Rectangle" // Upgrade that old Triangle to a Rectangle!

print(shapeList[2])

// We can add another item to the Array with the append method. This
// will add the new item at the end of the array list.

shapeList.append("Hexagon")

print(shapeList)

// You can clear an existing array and replace it with an empty, to do this
// simply set to []

shapeList = []

//------------------------------------------------------------------------------

// A Set is used to store distinct values of the same type when ordering isnt required.
// You can use a Set instead of an Array when the order of items is not important.

var numbers = Set<Character>()

print("This set currently has \(numbers.count) numbers.")

numbers.insert("1")

print("This set currently has \(numbers.count) numbers.")

numbers.insert("1") // This number set already has the number "1", so nothing will change.

print("This set currently has \(numbers.count) numbers.")

numbers.insert("2")

print("This set currently has \(numbers.count) numbers.")

//------------------------------------------------------------------------------

// This is how to create an empty dictionary that can hold key value pairs where
// the key is of type String and the value is of type Float.

var emptyDictionary = [String : Float]()

// This creates a dictionary of player names and their scores. The player's name
// is the key of type String, which points to the score which is the value of
// type Int.

var highScores = [
    "Calvin": 2100,
    "Jennifer": 2700,
    "Hannah": 2222,
    "Chris": 5000,
]

// We can access a specific player score in the list, py printing there name.

print(highScores["Chris"]!)

// We can also just print the entire leaderboard of scores.

print(highScores)

// We can manualy add a new key-value pairs to the dictionary.

highScores["Daisy"] = 4560

print(highScores)
